"""Loop screen: dense baselines, loop mechanisms, AttnRes and their combinations.

Design and pre-registered decision rules: docs/LOOP_SCREEN_20261123.md (round 1)
and docs/LOOP_SCREEN2_20261123.md (round 2). All arms reuse the EmbeddingAnchor
embedding, native dense Block and shared tokenwise head, so only the depth
computation differs. Middle "path" names stored block identities; for loop arms
path[0] is the prelude, path[1:3] the looped core and path[3] the coda.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from efficient_llm.dot_pool.model import Block, Config as BlockConfig
from .embedding_anchor import EmbeddingAnchor

# blocks: stored blocks; loop: None|serial|memory|gated; mix: residual|attnres; var: variable passes
SPECS = {
    'dense4': dict(blocks=4, loop=None, mix='residual', var=False, steps=12288),
    'dense4_2x': dict(blocks=4, loop=None, mix='residual', var=False, steps=24576),
    'dense8': dict(blocks=8, loop=None, mix='residual', var=False, steps=12288),
    'serial': dict(blocks=4, loop='serial', mix='residual', var=False, steps=12288),
    'memory': dict(blocks=4, loop='memory', mix='residual', var=False, steps=12288),
    'gated': dict(blocks=4, loop='gated', mix='residual', var=False, steps=12288),
    'gated_var': dict(blocks=4, loop='gated', mix='residual', var=True, steps=12288),
    'attnres': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288),
    # round 2
    'memory_var': dict(blocks=4, loop='memory', mix='residual', var=True, steps=12288),
    'memory_2x': dict(blocks=4, loop='memory', mix='residual', var=False, steps=24576),
    'loop_attnres': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=12288),
    'loop_attnres_var': dict(blocks=4, loop='serial', mix='attnres', var=True, steps=12288),
    'attnres8': dict(blocks=8, loop=None, mix='attnres', var=False, steps=12288),
    'attnres_2x': dict(blocks=4, loop=None, mix='attnres', var=False, steps=24576),
    # round 4: per-token random depth during training (copy-through, docs/LOOP_SCREEN4_20261123.md)
    'loop_attnres_tokvar': dict(blocks=4, loop='serial', mix='attnres', var='token', steps=12288),
    'gated_tokvar': dict(blocks=4, loop='gated', mix='residual', var='token', steps=12288),
    'loop_attnres_2x': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=24576),
    'dense8_2x': dict(blocks=8, loop=None, mix='residual', var=False, steps=24576),
    # scale round (docs/SCALE_ROUND_20261123.md): 4x data, rows extend into the other seed's array
    'loop_attnres_4x': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=49152),
    'attnres_4x': dict(blocks=4, loop=None, mix='attnres', var=False, steps=49152),
    'attnres8_4x': dict(blocks=8, loop=None, mix='attnres', var=False, steps=49152),
    'dense8_4x': dict(blocks=8, loop=None, mix='residual', var=False, steps=49152),
    'dense4_4x': dict(blocks=4, loop=None, mix='residual', var=False, steps=49152),
    # dynamic AttnRes (docs/MOE_DYN_ROUND_20261123.md): token-dependent depth queries, zero-init delta
    'dynattn': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288, dyn=True),
    'dynattn8': dict(blocks=8, loop=None, mix='attnres', var=False, steps=12288, dyn=True),
    'loop_dynattn': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=12288, dyn=True),
    # token-level MoE in the loop line (docs/MOE_LOOP_ROUND_20261123.md): the MLPs of the listed stored
    # blocks become 8 x FF/2 experts, Mixtral top-2, shared across loop passes; bounded dynamic AttnRes
    'attnres_moe': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288, moe=(1, 2)),
    'loop_attnres_moe': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=12288, moe=(1, 2)),
    'dense4_moe': dict(blocks=4, loop=None, mix='residual', var=False, steps=12288, moe=(1, 2)),
    'attnres8_moe': dict(blocks=8, loop=None, mix='attnres', var=False, steps=12288, moe=(1, 2, 3, 4, 5, 6)),
    'dynattn_tanh': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288, dyn='tanh'),
    # MoE variants (docs/MOE_VARIANTS_20261123.md): per-pass routers in the loop core (experts shared),
    # finer experts (16 x FF/4, top-4) and a DeepSeek-style shared expert (FF/2 + 8 x FF/4 top-2)
    'loop_attnres_moe_pr': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=12288, moe=(1, 2), moe_pass=3),
    'attnres_moe16': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288, moe=(1, 2),
                          moe_k=16, moe_top=4, moe_ffdiv=4),
    'attnres_moe_shared': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288, moe=(1, 2),
                               moe_ffdiv=4, moe_shared=True),
    # MoE at 4x data (docs/MOE_SCALE_20261123.md)
    'attnres_moe_4x': dict(blocks=4, loop=None, mix='attnres', var=False, steps=49152, moe=(1, 2)),
    'loop_attnres_moe_4x': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=49152, moe=(1, 2)),
    'attnres8_moe_4x': dict(blocks=8, loop=None, mix='attnres', var=False, steps=49152, moe=(1, 2, 3, 4, 5, 6)),
    # token-level DOT (docs/DOT_TOKEN_20261123.md): library of the 4 stored blocks, T steps per token
    'dot_route_t8': dict(blocks=4, loop=None, mix='dot', var=False, steps=12288, dot=dict(steps=8, mode='route', residual='multi')),
    'dot_fixed_t8': dict(blocks=4, loop=None, mix='dot', var=False, steps=12288, dot=dict(steps=8, mode='fixed', residual='multi')),
    'dot_random_t8': dict(blocks=4, loop=None, mix='dot', var=False, steps=12288, dot=dict(steps=8, mode='random', residual='multi')),
    'dot_route_res_t8': dict(blocks=4, loop=None, mix='dot', var=False, steps=12288, dot=dict(steps=8, mode='route', residual='plain')),
    'dot_route_t4': dict(blocks=4, loop=None, mix='dot', var=False, steps=12288, dot=dict(steps=4, mode='route', residual='multi')),
    # DOT sandwich, token-level router, no warm-up (docs/DOT_SANDWICH_20261123.md): T=block 0, middles 1..3, depth 3
    'sw_route': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                     sandwich=dict(depth=3, mode='route', residual='plain', recipient=True)),
    'sw_fixed': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                     sandwich=dict(depth=3, mode='fixed', residual='plain', recipient=True)),
    'sw_random': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                      sandwich=dict(depth=3, mode='random', residual='plain', recipient=True)),
    'sw_route_noid': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                          sandwich=dict(depth=3, mode='route', residual='plain', recipient=False)),
    'sw_route_multi': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                           sandwich=dict(depth=3, mode='route', residual='multi', recipient=True)),
    # router-training variants (user, 23 Nov 22:20 SGT): RL with explore/exploit, and try-every-module labels
    'sw_rl': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                  sandwich=dict(depth=3, mode='rl', residual='plain', recipient=True)),
    'sw_cf': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                  sandwich=dict(depth=3, mode='cf', residual='plain', recipient=True)),
    # a04 (docs/DOT_SANDWICH_20261123.md): routing as deviations from the fixed order, a larger middle library,
    # and stabilised versions of the user's two router-training ideas
    'sw_prior': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                     sandwich=dict(depth=3, mode='route', residual='plain', recipient=True, prior=True)),
    'sw6_route': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                      sandwich=dict(depth=3, mode='route', residual='plain', recipient=True, middles=6)),
    'sw6_prior': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                      sandwich=dict(depth=3, mode='route', residual='plain', recipient=True, middles=6, prior=True)),
    'sw_cf_soft': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                       sandwich=dict(depth=3, mode='cf', residual='plain', recipient=True, soft=True, balance=.1)),
    'sw_rl2': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                   sandwich=dict(depth=3, mode='rl', residual='plain', recipient=True, v2=True)),
    # a05 multi-path router training (user, 24 Nov): final-loss credit, several paths per token, bounded cost
    'sw_mpg': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                   sandwich=dict(depth=3, mode='mpg', residual='plain', recipient=True)),
    'sw_branch': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                      sandwich=dict(depth=3, mode='branch', residual='plain', recipient=True)),
    'sw_mpg_prior': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                         sandwich=dict(depth=3, mode='mpg', residual='plain', recipient=True, prior=True)),
    'sw_branch_prior': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                            sandwich=dict(depth=3, mode='branch', residual='plain', recipient=True, prior=True)),
    # a06 joint path + STOP policy (docs/DOT_STOP_SANDWICH_20261124.md): depth up to 4 middles
    'swst_dot_l02': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                         sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=.02)),
    'swst_dot_l05': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                         sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=.05)),
    'swst_fixed_l02': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                           sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=.02, fixed_path=True)),
    'swst_budget_l02': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                            sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=.02, budget=True)),
    'swst_route_d4': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                          sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=0., stop=False)),
    'swst_fixed_d4': dict(blocks=4, loop=None, mix='sandwich', var=False, steps=12288,
                          sandwich=dict(depth=4, mode='stop', residual='plain', recipient=True, lam=0., stop=False,
                                        fixed_path=True)),
}
# Synthetic DOT benchmark arms (docs/DOT_SYNTH_20261124.md); steps are set by the synthetic study.
_SYN = dict(blocks=4, loop=None, mix='sandwich', var=False, steps=0)
_SYN_SW = dict(mode='stop', residual='plain', recipient=True, context_credit=True, roll_rows=64)
SPECS.update({
    'syn_fixed_d4': dict(_SYN, sandwich=dict(_SYN_SW, depth=4, lam=0., stop=False, fixed_path=True)),
    'syn_fixed_d8': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=0., stop=False, fixed_path=True)),
    'syn_route_d8': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=0., stop=False)),
    'syn_stop_d8': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01)),
    'syn_stopfix_d8': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01, fixed_path=True)),
    'syn_budget_d8': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01, budget=True)),
    # s02: compute penalty only after half of training (the body first learns to use depth)
    'syn_stop_d8w': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01, lam_start=.5)),
    'syn_stopfix_d8w': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01, lam_start=.5, fixed_path=True)),
    'syn_budget_d8w': dict(_SYN, sandwich=dict(_SYN_SW, depth=8, lam=.01, lam_start=.5, budget=True)),
    # s05: equal trained depth 4 for routing vs fixed order; STOP at depth 4 (extended at inference)
    'syn_route_d4': dict(_SYN, sandwich=dict(_SYN_SW, depth=4, lam=0., stop=False)),
    'syn_stop_d4w': dict(_SYN, sandwich=dict(_SYN_SW, depth=4, lam=.01, lam_start=.5)),
    'syn_stopfix_d4w': dict(_SYN, sandwich=dict(_SYN_SW, depth=4, lam=.01, lam_start=.5, fixed_path=True)),
})
DYN_RANK = 32
DYN_BOUND = .05  # dyn='tanh': per-element query delta bounded to +-0.05 (trained AttnRes queries ~0.004-0.02)
MOE_EXPERTS, MOE_TOP, MOE_FF_DIV, MOE_BALANCE = 8, 2, 2, .01
ARMS = ('dense4', 'dense4_2x', 'dense8', 'serial', 'memory', 'gated', 'gated_var', 'attnres')  # round 1
ALL_ARMS = tuple(SPECS)
LOOP_ARMS = tuple(a for a, s in SPECS.items() if s['loop'])
STEPS = {a: s['steps'] for a, s in SPECS.items()}
VAR_PASSES = (3, 1, 3, 2, 3, 4, 3, 5)  # P(3)=1/2, P(1|2|4|5)=1/8 each, mean 3
NATIVE4 = (0, 1, 2, 3)
SWAP4 = (0, 2, 1, 3)
NATIVE8 = tuple(range(8))


def lr_at(step, total, peak=6e-4, warmup=128, cooldown=0.2):
    """Warmup-stable-decay: linear warm-up, constant, linear decay to 0 over the last 20%."""
    if type(step) is not int or not 0 <= step < total:
        raise ValueError('step outside schedule')
    start = int(total * (1 - cooldown))
    if step < warmup:
        return peak * (step + 1) / warmup
    if step < start:
        return peak
    return peak * (total - step) / (total - start)


def train_passes(arm, step):
    """Sequence-level pass count for a step (token-level arms run up to max(VAR_PASSES))."""
    spec = SPECS[arm]
    if spec['var'] == 'token':
        return max(VAR_PASSES)
    if spec['var']:
        return VAR_PASSES[step % len(VAR_PASSES)]
    return 3 if spec['loop'] else None


def token_pass_targets(shape, step, seed, device):
    """Per-token pass counts drawn from the VAR_PASSES distribution, deterministic in (seed, step)."""
    g = torch.Generator().manual_seed(1_000_003 * (seed + 1) + step)
    pick = torch.randint(0, len(VAR_PASSES), shape, generator=g)
    return torch.tensor(VAR_PASSES)[pick].to(device)


def block_applications(arm, passes=3):
    spec = SPECS[arm]
    if spec.get('dot'):
        return spec['dot']['steps']
    if spec.get('sandwich'):
        return 2 * spec['sandwich']['depth'] + 1
    return 2 + 2 * passes if spec['loop'] else spec['blocks']


def make_model(config, arm):
    """Model for any registered arm: LoopScreen, token-level DOT or DOT sandwich."""
    spec = SPECS[arm]
    if spec.get('dot'):
        from .dot_token import DotToken
        return DotToken(config, arm, spec)
    if spec.get('sandwich'):
        if spec['sandwich']['mode'] == 'stop':
            from .dot_stop_sandwich import DotSandwichStop
            return DotSandwichStop(config, arm, spec)
        from .dot_sandwich import DotSandwich
        return DotSandwich(config, arm, spec)
    return LoopScreen(config, arm)


def native_path(arm):
    return NATIVE8 if SPECS[arm]['blocks'] == 8 else NATIVE4


class LoopScreen(EmbeddingAnchor):
    def __init__(self, config, arm):
        super().__init__(config)  # identical base init (embed, B0..B3, head) for every arm
        if arm not in SPECS:
            raise ValueError('Unknown screen arm')
        self.arm = arm
        self.spec = SPECS[arm]
        self.passes = 3
        self.memory_enabled = True
        self.token_passes = None  # per-token pass targets (token-var arms, training only)
        d = config.d
        if self.spec['blocks'] == 8:
            bc = BlockConfig(d=d, heads=config.heads, kv_heads=config.kv_heads,
                             head_dim=config.head_dim, ff=config.ff)
            extra = [Block(bc, True) for _ in range(4)]
            for block in extra:
                for module in block.modules():
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=.02)
            self.blocks.extend(extra)
        if self.spec['loop'] == 'memory':
            self.memory_query = nn.Parameter(torch.zeros(2, d))
            self.memory_gain = nn.Parameter(torch.zeros(2, d))
        if self.spec['loop'] == 'gated':
            self.message_gate = nn.Parameter(torch.zeros(d))  # closed at init: every pass = one pass
        if self.spec['mix'] == 'attnres':
            # one pseudo-query per stored (block, sublayer), shared across loop passes, plus readout
            self.attnres_query = nn.Parameter(torch.zeros(2 * self.spec['blocks'] + 1, d))
        if self.spec.get('dyn'):
            # q_l(t) = w_l + B_l A_l RMSNorm(latest source at t); B zero-init, so training starts as AttnRes
            n = 2 * self.spec['blocks'] + 1
            self.attnres_dyn_a = nn.Parameter(torch.randn(n, d, DYN_RANK) / math.sqrt(d))
            self.attnres_dyn_b = nn.Parameter(torch.zeros(n, DYN_RANK, d))
        self.aux = None
        self.moe_trace = None  # set to {} to record top-k expert indices per (block, application)
        if self.spec.get('moe'):
            from efficient_llm.dot_pool.model import MLP
            k, ff = self.moe_k, config.ff // self.spec.get('moe_ffdiv', MOE_FF_DIV)
            self.moe_experts = nn.ModuleDict({str(i): nn.ModuleList(MLP(d, ff) for _ in range(k)) for i in self.spec['moe']})
            for module in self.moe_experts.modules():
                if isinstance(module, nn.Linear):
                    nn.init.normal_(module.weight, std=.02)
            # small random router init: no exact top-k ties (CPU/GPU tie-breaking could differ)
            self.moe_router = nn.ParameterDict({str(i): nn.Parameter(torch.randn(k, d) * .02) for i in self.spec['moe']})
            for i in self.spec['moe']:
                self.register_buffer(f'moe_usage_{i}', torch.full((k,), 1. / k))
            # extra parameters are created after the base MoE ones, so base MoE arms keep their init
            for i in self.spec['moe']:
                for p in range(1, self.spec.get('moe_pass', 1)):
                    self.moe_router[f'{i}_p{p}'] = nn.Parameter(torch.randn(k, d) * .02)
            if self.spec.get('moe_shared'):
                self.moe_shared = nn.ModuleDict({str(i): MLP(d, config.ff // 2) for i in self.spec['moe']})
                for module in self.moe_shared.modules():
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=.02)

    @property
    def moe_k(self):
        return self.spec.get('moe_k', MOE_EXPERTS)

    @property
    def moe_top(self):
        return self.spec.get('moe_top', MOE_TOP)

    # ---- shared helpers -------------------------------------------------
    def _guard(self, x):
        from .embedding_anchor_runtime import anchor_device
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if x.ndim != 2 or not 1 <= x.shape[1] <= self.c.length:
            raise ValueError('Invalid token matrix')

    def _check_path(self, path):
        path = tuple(path)
        expected = set(range(self.spec['blocks']))
        if set(path) != expected or len(path) != len(expected):
            raise ValueError('Path must be a permutation of all stored blocks')
        if self.spec['loop'] and (path[0], path[3]) != (0, 3):
            raise ValueError('Loop arms keep prelude 0 and coda 3 fixed')
        if self.spec['loop'] and not 1 <= self.passes <= 16:
            raise ValueError('Pass count outside supported range')
        return path

    def read_memory(self, h, sources, identity):
        # Identical to anchor_loop.LoopAnchor.read_memory (completed long-loop study).
        values = torch.stack([F.rms_norm(v.float(), (self.c.d,), eps=1e-6) for v in sources], dim=-2)
        q = self.memory_query[identity - 1]
        weights = torch.softmax((values * q).sum(dim=-1) / math.sqrt(self.c.d), dim=-1)
        message = (values * weights.unsqueeze(-1)).sum(dim=-2)
        scale = (h.float().square().mean(dim=-1, keepdim=True) + 1e-6).sqrt()
        return h + scale * self.memory_gain[identity - 1].tanh() * message

    def _attnres_mix(self, sources, index):
        """Kimi AttnRes: softmax over depth of w^T RMSNorm(v_i), w zero-init -> uniform mean."""
        values = torch.stack(sources, dim=0)
        keys = F.rms_norm(values.float(), (self.c.d,), eps=1e-6)
        query = self.attnres_query[index].float()
        if self.spec.get('dyn'):
            state = keys[-1]  # RMSNorm of the latest source at each token
            delta = (state @ self.attnres_dyn_a[index].float()) @ self.attnres_dyn_b[index].float()
            query = query + (DYN_BOUND * torch.tanh(delta) if self.spec['dyn'] == 'tanh' else delta)
        logits = (keys * query).sum(-1)
        weights = torch.softmax(logits, dim=0).to(values.dtype)
        return (weights.unsqueeze(-1) * values).sum(0)

    def _mlp(self, identity, u, application=0):
        if not self.spec.get('moe') or identity not in self.spec['moe']:
            return self.blocks[identity].mlp(u)
        experts, k, top = self.moe_experts[str(identity)], self.moe_k, self.moe_top
        key = str(identity)
        if self.spec.get('moe_pass') and application:  # per-pass router; extra eval passes reuse the last one
            key = f"{identity}_p{min(application, self.spec['moe_pass'] - 1)}"
        probs = torch.softmax(F.rms_norm(u.float(), (self.c.d,), eps=1e-6) @ self.moe_router[key].float().t(), -1)
        value, index = probs.topk(top, -1)
        value = value / value.sum(-1, keepdim=True)  # Mixtral: renormalized over the chosen experts
        weights = sum(F.one_hot(index[..., j], k).to(probs.dtype) * value[..., j:j + 1] for j in range(top))
        out = sum(weights[..., i:i + 1].to(u.dtype) * experts[i](u) for i in range(k))  # exact top-k
        if self.spec.get('moe_shared'):
            out = out + self.moe_shared[str(identity)](u)
        if self.moe_trace is not None:
            self.moe_trace.setdefault(identity, []).append(index.detach())
        if self.training and torch.is_grad_enabled():
            frac = sum(F.one_hot(index[..., j], k).float() for j in range(top)).reshape(-1, k).mean(0) / top
            with torch.no_grad():
                usage = getattr(self, f'moe_usage_{identity}')
                usage.mul_(.95).add_(.05 * frac)
            balance = MOE_BALANCE * k * (frac.detach() * probs.reshape(-1, k).mean(0)).sum()
            self.aux = balance if self.aux is None else self.aux + balance
        return out

    def _block(self, identity, h, pos, seg):
        if not self.spec.get('moe') or identity not in self.spec['moe']:
            return self.blocks[identity](h, pos, seg)
        block = self.blocks[identity]
        h = block.attention(h, pos, seg)
        return h + self._mlp(identity, block.post_attention_layernorm(h))

    def application_order(self, path):
        """Stored block identities in execution order (loops unrolled)."""
        if not self.spec['loop']:
            return tuple(path)
        return (path[0], *(path[1:3] * self.passes), path[3])

    # ---- forward ----------------------------------------------------------
    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('Screen arms take no anchor, donor or skip options')
        if self.token_passes is not None:
            from .loop_stop import halted_hidden
            targets = self.token_passes
            if targets.shape != x.shape:
                raise ValueError('token_passes must match the token matrix')
            return halted_hidden(self, x, path, int(targets.max()), lambda k, s: targets <= k)[0]
        self._guard(x)
        path = self._check_path(path)
        self.aux = None
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        e = self.embed(x)
        if self.spec['mix'] == 'attnres':
            return self._attnres_hidden(e, self.application_order(path), pos, seg)
        if not self.spec['loop']:
            h = e
            for identity in path:
                h = self._block(identity, h, pos, seg)
            return h
        prelude = self.blocks[path[0]](e, pos, seg)
        core = path[1:3]
        if self.spec['loop'] == 'gated':
            message = None
            for _ in range(self.passes):
                h = prelude if message is None else prelude + self.message_gate * (message - prelude)
                for identity in core:
                    h = self.blocks[identity](h, pos, seg)
                message = h
            return self.blocks[path[3]](message, pos, seg)
        h = prelude
        previous = ()
        for _ in range(self.passes):
            current = []
            for identity in core:
                if self.spec['loop'] == 'memory' and self.memory_enabled:
                    h = self.read_memory(h, (e, prelude, *previous), identity)
                h = self.blocks[identity](h, pos, seg)
                current.append(h)
            previous = tuple(current)
        return self.blocks[path[3]](h, pos, seg)

    def _attnres_hidden(self, e, order, pos, seg):
        sources = [e]
        seen = {}
        for identity in order:
            block = self.blocks[identity]
            x = self._attnres_mix(sources, 2 * identity)
            sources.append(block.self_attn(block.input_layernorm(x), pos, seg))
            x = self._attnres_mix(sources, 2 * identity + 1)
            application = seen.get(identity, 0)
            seen[identity] = application + 1
            sources.append(self._mlp(identity, block.post_attention_layernorm(x), application))
        return self._attnres_mix(sources, 2 * self.spec['blocks'])
