"""Loop screen: dense baselines, loop mechanisms, AttnRes and their combinations.

Design and pre-registered decision rules: docs/LOOP_SCREEN_20261123.md (round 1)
and docs/LOOP_SCREEN2_20261123.md (round 2). All arms reuse the EmbeddingAnchor
embedding, native dense Block and shared tokenwise head, so only the depth
computation differs. Middle "path" names stored block identities; for loop arms
path[0] is the prelude, path[1:3] the looped core and path[3] the coda.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from efficient_llm.dot_pool.model import Block, Config as BlockConfig
from .embedding_anchor import EmbeddingAnchor

# blocks: stored blocks; loop: None|serial|memory|gated; mix: residual|attnres; var: variable passes
SPECS = {
    'dense4': dict(blocks=4, loop=None, mix='residual', var=False, steps=12288),
    'dense4_2x': dict(blocks=4, loop=None, mix='residual', var=False, steps=24576),
    'dense8': dict(blocks=8, loop=None, mix='residual', var=False, steps=12288),
    'serial': dict(blocks=4, loop='serial', mix='residual', var=False, steps=12288),
    'memory': dict(blocks=4, loop='memory', mix='residual', var=False, steps=12288),
    'gated': dict(blocks=4, loop='gated', mix='residual', var=False, steps=12288),
    'gated_var': dict(blocks=4, loop='gated', mix='residual', var=True, steps=12288),
    'attnres': dict(blocks=4, loop=None, mix='attnres', var=False, steps=12288),
    # round 2
    'memory_var': dict(blocks=4, loop='memory', mix='residual', var=True, steps=12288),
    'memory_2x': dict(blocks=4, loop='memory', mix='residual', var=False, steps=24576),
    'loop_attnres': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=12288),
    'loop_attnres_var': dict(blocks=4, loop='serial', mix='attnres', var=True, steps=12288),
    'attnres8': dict(blocks=8, loop=None, mix='attnres', var=False, steps=12288),
    'attnres_2x': dict(blocks=4, loop=None, mix='attnres', var=False, steps=24576),
    # round 4: per-token random depth during training (copy-through, docs/LOOP_SCREEN4_20261123.md)
    'loop_attnres_tokvar': dict(blocks=4, loop='serial', mix='attnres', var='token', steps=12288),
    'gated_tokvar': dict(blocks=4, loop='gated', mix='residual', var='token', steps=12288),
    'loop_attnres_2x': dict(blocks=4, loop='serial', mix='attnres', var=False, steps=24576),
    'dense8_2x': dict(blocks=8, loop=None, mix='residual', var=False, steps=24576),
}
ARMS = ('dense4', 'dense4_2x', 'dense8', 'serial', 'memory', 'gated', 'gated_var', 'attnres')  # round 1
ALL_ARMS = tuple(SPECS)
LOOP_ARMS = tuple(a for a, s in SPECS.items() if s['loop'])
STEPS = {a: s['steps'] for a, s in SPECS.items()}
VAR_PASSES = (3, 1, 3, 2, 3, 4, 3, 5)  # P(3)=1/2, P(1|2|4|5)=1/8 each, mean 3
NATIVE4 = (0, 1, 2, 3)
SWAP4 = (0, 2, 1, 3)
NATIVE8 = tuple(range(8))


def lr_at(step, total, peak=6e-4, warmup=128, cooldown=0.2):
    """Warmup-stable-decay: linear warm-up, constant, linear decay to 0 over the last 20%."""
    if type(step) is not int or not 0 <= step < total:
        raise ValueError('step outside schedule')
    start = int(total * (1 - cooldown))
    if step < warmup:
        return peak * (step + 1) / warmup
    if step < start:
        return peak
    return peak * (total - step) / (total - start)


def train_passes(arm, step):
    """Sequence-level pass count for a step (token-level arms run up to max(VAR_PASSES))."""
    spec = SPECS[arm]
    if spec['var'] == 'token':
        return max(VAR_PASSES)
    if spec['var']:
        return VAR_PASSES[step % len(VAR_PASSES)]
    return 3 if spec['loop'] else None


def token_pass_targets(shape, step, seed, device):
    """Per-token pass counts drawn from the VAR_PASSES distribution, deterministic in (seed, step)."""
    g = torch.Generator().manual_seed(1_000_003 * (seed + 1) + step)
    pick = torch.randint(0, len(VAR_PASSES), shape, generator=g)
    return torch.tensor(VAR_PASSES)[pick].to(device)


def block_applications(arm, passes=3):
    spec = SPECS[arm]
    return 2 + 2 * passes if spec['loop'] else spec['blocks']


def native_path(arm):
    return NATIVE8 if SPECS[arm]['blocks'] == 8 else NATIVE4


class LoopScreen(EmbeddingAnchor):
    def __init__(self, config, arm):
        super().__init__(config)  # identical base init (embed, B0..B3, head) for every arm
        if arm not in SPECS:
            raise ValueError('Unknown screen arm')
        self.arm = arm
        self.spec = SPECS[arm]
        self.passes = 3
        self.memory_enabled = True
        self.token_passes = None  # per-token pass targets (token-var arms, training only)
        d = config.d
        if self.spec['blocks'] == 8:
            bc = BlockConfig(d=d, heads=config.heads, kv_heads=config.kv_heads,
                             head_dim=config.head_dim, ff=config.ff)
            extra = [Block(bc, True) for _ in range(4)]
            for block in extra:
                for module in block.modules():
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=.02)
            self.blocks.extend(extra)
        if self.spec['loop'] == 'memory':
            self.memory_query = nn.Parameter(torch.zeros(2, d))
            self.memory_gain = nn.Parameter(torch.zeros(2, d))
        if self.spec['loop'] == 'gated':
            self.message_gate = nn.Parameter(torch.zeros(d))  # closed at init: every pass = one pass
        if self.spec['mix'] == 'attnres':
            # one pseudo-query per stored (block, sublayer), shared across loop passes, plus readout
            self.attnres_query = nn.Parameter(torch.zeros(2 * self.spec['blocks'] + 1, d))

    # ---- shared helpers -------------------------------------------------
    def _guard(self, x):
        from .embedding_anchor_runtime import anchor_device
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if x.ndim != 2 or not 1 <= x.shape[1] <= self.c.length:
            raise ValueError('Invalid token matrix')

    def _check_path(self, path):
        path = tuple(path)
        expected = set(range(self.spec['blocks']))
        if set(path) != expected or len(path) != len(expected):
            raise ValueError('Path must be a permutation of all stored blocks')
        if self.spec['loop'] and (path[0], path[3]) != (0, 3):
            raise ValueError('Loop arms keep prelude 0 and coda 3 fixed')
        if self.spec['loop'] and not 1 <= self.passes <= 16:
            raise ValueError('Pass count outside supported range')
        return path

    def read_memory(self, h, sources, identity):
        # Identical to anchor_loop.LoopAnchor.read_memory (completed long-loop study).
        values = torch.stack([F.rms_norm(v.float(), (self.c.d,), eps=1e-6) for v in sources], dim=-2)
        q = self.memory_query[identity - 1]
        weights = torch.softmax((values * q).sum(dim=-1) / math.sqrt(self.c.d), dim=-1)
        message = (values * weights.unsqueeze(-1)).sum(dim=-2)
        scale = (h.float().square().mean(dim=-1, keepdim=True) + 1e-6).sqrt()
        return h + scale * self.memory_gain[identity - 1].tanh() * message

    def _attnres_mix(self, sources, index):
        """Kimi AttnRes: softmax over depth of w^T RMSNorm(v_i), w zero-init -> uniform mean."""
        values = torch.stack(sources, dim=0)
        keys = F.rms_norm(values.float(), (self.c.d,), eps=1e-6)
        logits = (keys * self.attnres_query[index].float()).sum(-1)
        weights = torch.softmax(logits, dim=0).to(values.dtype)
        return (weights.unsqueeze(-1) * values).sum(0)

    def application_order(self, path):
        """Stored block identities in execution order (loops unrolled)."""
        if not self.spec['loop']:
            return tuple(path)
        return (path[0], *(path[1:3] * self.passes), path[3])

    # ---- forward ----------------------------------------------------------
    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('Screen arms take no anchor, donor or skip options')
        if self.token_passes is not None:
            from .loop_stop import halted_hidden
            targets = self.token_passes
            if targets.shape != x.shape:
                raise ValueError('token_passes must match the token matrix')
            return halted_hidden(self, x, path, int(targets.max()), lambda k, s: targets <= k)[0]
        self._guard(x)
        path = self._check_path(path)
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        e = self.embed(x)
        if self.spec['mix'] == 'attnres':
            return self._attnres_hidden(e, self.application_order(path), pos, seg)
        if not self.spec['loop']:
            h = e
            for identity in path:
                h = self.blocks[identity](h, pos, seg)
            return h
        prelude = self.blocks[path[0]](e, pos, seg)
        core = path[1:3]
        if self.spec['loop'] == 'gated':
            message = None
            for _ in range(self.passes):
                h = prelude if message is None else prelude + self.message_gate * (message - prelude)
                for identity in core:
                    h = self.blocks[identity](h, pos, seg)
                message = h
            return self.blocks[path[3]](message, pos, seg)
        h = prelude
        previous = ()
        for _ in range(self.passes):
            current = []
            for identity in core:
                if self.spec['loop'] == 'memory' and self.memory_enabled:
                    h = self.read_memory(h, (e, prelude, *previous), identity)
                h = self.blocks[identity](h, pos, seg)
                current.append(h)
            previous = tuple(current)
        return self.blocks[path[3]](h, pos, seg)

    def _attnres_hidden(self, e, order, pos, seg):
        sources = [e]
        for identity in order:
            block = self.blocks[identity]
            x = self._attnres_mix(sources, 2 * identity)
            sources.append(block.self_attn(block.input_layernorm(x), pos, seg))
            x = self._attnres_mix(sources, 2 * identity + 1)
            sources.append(block.mlp(block.post_attention_layernorm(x)))
        return self._attnres_mix(sources, 2 * self.spec['blocks'])
