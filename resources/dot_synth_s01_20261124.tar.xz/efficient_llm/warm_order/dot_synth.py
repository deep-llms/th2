"""Synthetic tasks where input-dependent depth, revisiting a module and STOP should matter (docs/DOT_SYNTH_20261124.md).

Every task has a fixed-length prompt with the answer at the end, so config.prefix = answer start and the standard
token_losses (and the DOT rollouts) score only answer tokens. Difficulty varies WITHOUT changing the sequence length or
introducing unseen tokens, so models can be tested beyond the training difficulty.

  chain : N nodes form disjoint chains (node -> next node, last node -> END), listed as shuffled (node, successor)
          pairs. Query: a start node x; answer: the last node of x's chain. The query chain has k hops (k + 1 nodes);
          the other nodes form distractor chains of random lengths 1..CHAIN_MAX, the same distribution in train and
          test. The model must follow pointers until END: repeated lookups (revisiting) and a data-dependent stop.
          Train k = 1..4, test k = 1..8.
  opseq : apply a listed sequence of string operations (padded with NOP to M_MAX) to an 8-digit string; output the
          result. Train m = 1..3 operations, test m = 1..6 (composition length; each operation is a natural module).
"""
import numpy as np
import torch

PAD, SEP, QUERY, NOP, END = 0, 1, 2, 3, 4
NODE0, N_NODES, CHAIN_MAX = 16, 16, 8  # node ids [16, 48); labels are a random subset of 32 symbols
SYMBOLS = 32
DIGIT0 = 64  # digits 0..9
OP0 = 80  # operation tokens
OPS = ('rev', 'rotl', 'inc', 'swap')
STR_LEN, M_MAX = 8, 6
VOCAB = 128


def chain_spec():
    length = 2 * N_NODES + 3  # pairs, SEP, x, answer
    return dict(length=length, prefix=length - 1)


def chain_batch(n, ks, rng):
    """n sequences with query hop counts drawn uniformly from ks. Returns (tokens [n, length] int64, k per row)."""
    spec = chain_spec()
    out = np.zeros((n, spec['length']), dtype=np.int64)
    k = rng.choice(np.asarray(ks), size=n)
    for r in range(n):
        labels = NODE0 + rng.permutation(SYMBOLS)[:N_NODES]
        lengths = [int(k[r]) + 1]
        rest = N_NODES - lengths[0]
        while rest:
            m = int(rng.integers(1, min(CHAIN_MAX, rest) + 1))
            lengths.append(m)
            rest -= m
        succ, i = {}, 0
        for j, m in enumerate(lengths):
            chain = labels[i:i + m]
            for a, b in zip(chain[:-1], chain[1:]):
                succ[int(a)] = int(b)
            succ[int(chain[-1])] = END
            if j == 0:
                x, y = int(chain[0]), int(chain[-1])
            i += m
        keys = rng.permutation(np.fromiter(succ.keys(), dtype=np.int64))
        out[r, :2 * N_NODES] = np.stack([keys, [succ[int(a)] for a in keys]], 1).reshape(-1)
        out[r, 2 * N_NODES:] = (SEP, x, y)
    return out, k


def _apply(op, s):
    if op == 'rev':
        return s[::-1]
    if op == 'rotl':
        return s[1:] + s[:1]
    if op == 'inc':
        return [(c + 1) % 10 for c in s]
    if op == 'swap':
        t = list(s)
        for i in range(0, len(t) - 1, 2):
            t[i], t[i + 1] = t[i + 1], t[i]
        return t
    raise ValueError(op)


def opseq_spec():
    length = M_MAX + 1 + STR_LEN + 1 + STR_LEN  # ops (NOP padded), SEP, string, QUERY, answer string
    return dict(length=length, prefix=length - STR_LEN)


def opseq_batch(n, ms, rng):
    spec = opseq_spec()
    out = np.zeros((n, spec['length']), dtype=np.int64)
    m = rng.choice(np.asarray(ms), size=n)
    for r in range(n):
        ops = [OPS[i] for i in rng.integers(0, len(OPS), size=int(m[r]))]
        s = [int(c) for c in rng.integers(0, 10, size=STR_LEN)]
        t = s
        for op in ops:
            t = _apply(op, t)
        op_tokens = [OP0 + OPS.index(o) for o in ops] + [NOP] * (M_MAX - len(ops))
        out[r] = op_tokens + [SEP] + [DIGIT0 + c for c in s] + [QUERY] + [DIGIT0 + c for c in t]
    return out, m


TASKS = {
    'chain': dict(spec=chain_spec, batch=chain_batch, train=(1, 2, 3, 4), test=(1, 2, 3, 4, 5, 6, 7, 8)),
    'opseq': dict(spec=opseq_spec, batch=opseq_batch, train=(1, 2, 3), test=(1, 2, 3, 4, 5, 6)),
}


def to_device(tokens, device):
    return torch.as_tensor(tokens, dtype=torch.long, device=device)
