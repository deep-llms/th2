"""DOT sandwich with a joint path + STOP policy per token (docs/DOT_STOP_SANDWICH_20261124.md).

User (24 Nov): order can change without losing quality, so STOP may find cheaper exits when paths are diverse; path and
STOP learning should inform each other; option: decide a token's depth early. At every step each still-active token
picks one of the K middles OR STOP (one policy, K+1 actions); STOP freezes the token (copy-through; its state still
serves as keys/values) and the final tied translator T(., c_OUT) + head read every token out once at the end.
Variants: fixed_path (only continue/STOP is learned on the fixed middle order), budget (a step-0 head picks the number
of middles 1..D, then the path is routed within it), stop disabled (pure routing at depth D).

Training: the body learns on the policy's SAMPLED path (every depth gets exposure); the policy learns from G sampled
full paths per token judged by the final loss plus lambda x middles used, with a leave-one-out baseline (RLOO).
Anti-collapse: SAC-style adaptive entropy coefficient towards a target entropy, and an exploration schedule
(epsilon-uniform mixing decaying over the first 30% of training). Evaluation is greedy.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from .dot_sandwich import PRIOR_BETA, DotSandwich, T_ID

ROLL_PATHS, ROLL_ROWS, PG_WEIGHT, ADV_CLIP = 4, 8, .3, 3.
EPS0, EPS_MIN, EPS_DECAY = .2, .02, .3
ENT_ALPHA0, ENT_LR, ENT_TARGET_FRAC = .01, .01, .5
LAM_RAMP = .25


class DotSandwichStop(DotSandwich):
    def __init__(self, config, arm, spec):
        super().__init__(config, arm, spec)
        sw, d, k = self.sw, config.d, len(self.middles)
        self.stop_index = k
        self.stop_router = nn.Parameter(torch.randn(sw['depth'], k + 1, d) * .02)
        if sw.get('budget'):
            self.budget_router = nn.Parameter(torch.randn(sw['depth'], d) * .02)  # budget b = index + 1 middles
        self.register_buffer('log_alpha', torch.tensor(math.log(ENT_ALPHA0)))
        self.train_progress = 0.
        self.records = None  # rollout collector: list of (logits_fn args) for the policy gradient
        self.answer_mask = None  # synthetic tasks: bool (L - prefix,) of scored answer positions in the suffix
        self.last_used = None

    # ----- policy ------------------------------------------------------------------------------
    def _allowed(self, step, shape, device):
        k, sw = self.stop_index, self.sw
        allowed = torch.ones(*shape, k + 1, dtype=torch.bool, device=device)
        if step == 0 or not sw.get('stop', True) or sw.get('budget'):
            allowed[..., k] = False  # at least one middle; STOP decided by the budget head or disabled
        if sw.get('fixed_path'):
            keep = torch.zeros(k + 1, dtype=torch.bool, device=device)
            keep[self.sw.get('fixed_middle', step % 3)] = True  # fixed_middle: always the same middle (a pure loop)
            keep[k] = True
            allowed &= keep
        return allowed

    def _policy_logits(self, state, step, allowed):
        step_r = min(step, self.stop_router.shape[0] - 1)  # extra evaluation steps reuse the last trained step
        logits = F.rms_norm(state.float(), (self.c.d,), eps=1e-6) @ self.stop_router[step_r].float().t()
        if self.sw.get('prior'):  # fixed-order prior: training starts as the fixed sandwich, the router may deviate
            logits = logits + PRIOR_BETA * F.one_hot(torch.tensor(step % 3, device=logits.device), logits.shape[-1])
        return logits.masked_fill(~allowed, float('-inf'))

    def _lam(self):
        """Compute penalty; with sw['lam_start'] it is 0 before that training fraction and ramps up over LAM_RAMP."""
        lam, start = float(self.sw.get('lam', 0.)), self.sw.get('lam_start')
        if start is None:
            return lam
        return lam * min(1., max(0., (self.train_progress - start) / LAM_RAMP))

    def _epsilon(self):
        return max(EPS_MIN, EPS0 * (1 - self.train_progress / EPS_DECAY))

    def _sample(self, logits, allowed, eps):
        probs = torch.softmax(logits, -1)
        uniform = allowed.float() / allowed.float().sum(-1, keepdim=True)
        mix = (1 - eps) * probs + eps * uniform
        u = torch.rand(mix.shape[:-1], generator=self.generator, device=mix.device)
        return (mix.cumsum(-1) < u.unsqueeze(-1)).sum(-1).clamp(max=mix.shape[-1] - 1)

    # ----- forward -----------------------------------------------------------------------------
    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        from .embedding_anchor_runtime import anchor_device
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('DOT stop sandwich takes no anchor, donor or skip options')
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if tuple(path) != (0, 1, 2, 3):
            raise ValueError('DOT stop sandwich takes the native library path only')
        if self.sw['residual'] != 'plain':
            raise ValueError('stop sandwich uses the plain residual stream')
        sample = self.training and (torch.is_grad_enabled() or self.records is not None)
        if self.sw.get('body_greedy') and self.records is None:
            sample = False  # the body trains on the greedy path; only the policy rollouts sample
        if sample and self.generator is None:
            raise RuntimeError('sampled paths need an explicit generator')
        return self._run(x, sample)

    def _run(self, x, sample):
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        self.aux = None
        T, k = self.blocks[T_ID], self.stop_index
        depth = self.test_depth or self.sw['depth']
        eps = self._epsilon() if sample else 0.
        h = self.embed(x)
        active = torch.ones(x.shape, dtype=torch.bool, device=x.device)
        used = torch.zeros(x.shape, dtype=torch.long, device=x.device)
        entropies = []
        budget = None
        if self.sw.get('budget'):
            blog = F.rms_norm(h.float(), (self.c.d,), eps=1e-6) @ self.budget_router.float().t()
            ball = torch.ones(*x.shape, self.budget_router.shape[0], dtype=torch.bool, device=x.device)
            bidx = self._sample(blog, ball, eps) if sample else blog.argmax(-1)
            budget = bidx + 1
            if self.records is not None:
                self.records.append(('budget', h.detach(), bidx, active.clone(), ball))
            if sample and torch.is_grad_enabled():
                entropies.append(torch.distributions.Categorical(logits=blog).entropy())
        for step in range(depth):
            allowed = self._allowed(step, x.shape, x.device)
            logits = self._policy_logits(h, step, allowed)
            a = self._sample(logits, allowed, eps) if sample else logits.argmax(-1)
            if budget is not None:
                a = torch.where(step >= budget, torch.full_like(a, k), a)
            decide = active if budget is None else active & (step < budget)
            if self.records is not None:
                self.records.append((step, h.detach(), a, decide.clone(), allowed))
            if sample and torch.is_grad_enabled():
                lp = torch.log_softmax(logits, -1)
                ent = -(lp.exp() * lp.masked_fill(~allowed, 0.)).sum(-1)
                entropies.append(ent[decide])
            go = active & (a != k)
            if self.trace is not None:
                self.trace.append(torch.where(go, a, torch.full_like(a, k)).detach())
            choice = torch.where(go, a, torch.zeros_like(a))
            h_t = self._t(T, h, self._condition(choice, h.dtype), pos, seg)
            onehot = F.one_hot(choice, k).to(h.dtype)
            att = 0
            for j, b in enumerate(self.middles):
                att = att + onehot[..., j:j + 1] * self.blocks[b].self_attn(self.blocks[b].input_layernorm(h_t), pos, seg)
            h_m = h_t + att
            h_m = h_m + self._middle_mlp(h_m, choice)
            h = torch.where(go.unsqueeze(-1), h_m, h)  # stopped tokens are frozen (copy-through)
            used = used + go.long()
            active = go
        if entropies and torch.is_grad_enabled():
            flat = torch.cat([e.reshape(-1) for e in entropies])
            if flat.numel():
                entropy = flat.mean()
                n_allowed = float(k + 1)
                target = ENT_TARGET_FRAC * math.log(n_allowed)
                with torch.no_grad():
                    self.log_alpha.add_(ENT_LR * (target - float(entropy))).clamp_(math.log(1e-4), math.log(1.))
                self.aux = -self.log_alpha.exp().detach() * entropy
        self.last_used = used.detach()
        out = torch.full(x.shape, k, dtype=torch.long, device=x.device)
        return self._t(T, h, self._condition(out, h.dtype), pos, seg)

    # ----- policy learning -----------------------------------------------------------------------
    def _extra_loss(self, x, token_losses):
        """RLOO over ROLL_PATHS sampled full paths per token: cost = final loss + lambda x middles used.

        With sw['context_credit'] (synthetic tasks, where only the answer is scored) unscored context positions are
        also policy decisions; each gets its row's mean answer loss as outcome (plus its own compute penalty)."""
        if not self.training:
            return None
        lam, p0 = self._lam(), self.c.prefix - 1
        lo = 0 if self.sw.get('context_credit') else p0
        xs = x[:min(self.sw.get('roll_rows', ROLL_ROWS), x.shape[0])]
        records, costs = [], []
        with torch.no_grad():
            for _ in range(ROLL_PATHS):
                self.records = []
                try:
                    tl = super(DotSandwich, self).token_losses(xs, (0, 1, 2, 3))  # EmbeddingAnchor.token_losses
                    if self.answer_mask is not None:  # unscored queries inside the suffix: row-mean answer outcome
                        m = self.answer_mask.to(tl.device).float()
                        tl = torch.where(m.bool(), tl, ((tl * m).sum(1, keepdim=True) / m.sum()).expand_as(tl))
                    if lo < p0:
                        tl = torch.cat([tl.mean(1, keepdim=True).expand(-1, p0 - lo), tl], 1)
                    costs.append(tl + lam * self.last_used[:, lo:-1].float())
                finally:
                    records.append(self.records)
                    self.records = None
        C = torch.stack(costs)  # (paths, rows, L - 1 - lo)
        adv = C - (C.sum(0, keepdim=True) - C) / (ROLL_PATHS - 1)
        adv = (adv / (adv.std(0, keepdim=True) + 1e-6)).clamp(-ADV_CLIP, ADV_CLIP)
        total = 0
        for g, record in enumerate(records):
            for step, state, action, decide, allowed in record:
                if step == 'budget':
                    logits = F.rms_norm(state.float(), (self.c.d,), eps=1e-6) @ self.budget_router.float().t()
                else:
                    logits = self._policy_logits(state, step, allowed)
                logp = torch.log_softmax(logits, -1).gather(-1, action.unsqueeze(-1)).squeeze(-1)
                mask = decide[:, lo:-1].float()
                total = total + (logp[:, lo:-1].masked_fill(mask == 0, 0.) * adv[g] * mask).sum() / mask.sum().clamp(min=1.)
        return PG_WEIGHT * total / ROLL_PATHS
