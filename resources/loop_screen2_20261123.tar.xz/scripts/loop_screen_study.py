"""Loop screen rounds (8 jobs, one GPU each) from scratch on verified DCLM rows.

Round 1: docs/LOOP_SCREEN_20261123.md (seed 0, eight arms).
Round 2: docs/LOOP_SCREEN2_20261123.md (seed-1 confirmations plus combinations).
Reuses the verified long-study row arrays (seed s uses rows/s{s}.npy), the
registered per-seed measurement and calibration rows, and the owned native-burn
handoff supervisor from the completed anchor studies.
"""
import argparse
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from efficient_llm.warm_order.adaptation_runtime import measurement_runtime, training_runtime
from efficient_llm.warm_order.data import Rows, sha
from efficient_llm.warm_order.embedding_anchor_runtime import anchor_runtime
from efficient_llm.warm_order.horizon_train import write_json
from efficient_llm.warm_order.loop_screen import (ALL_ARMS, ARMS, LOOP_ARMS, SPECS, STEPS, SWAP4, LoopScreen,
                                                  block_applications, lr_at, native_path, train_passes)
from efficient_llm.warm_order.model import Config
from scripts.anchor_long_study import manifest, read, save_state, score
from scripts.anchor_long_queue import stage, supervise

OUTPUTS = Path('/mnt/local/_outputs/deep-llms_th2')
OLD = OUTPUTS/'anchor_long_20261122_a01'
ROW_PINS = ('70fc5792ed95b9ad3931a9604f29670d6769905407c06eb24a62cf8df0fe2853',  # verified long-study rows
            '46f6f3bd65b08297396799b458c91ac5c034293a364244d4e9fb02acf122e0b9')
ROUNDS = {
    1: [(0, a) for a in ARMS],
    2: [(1, 'memory'), (1, 'dense8'), (0, 'memory_var'), (0, 'loop_attnres'), (0, 'loop_attnres_var'),
        (0, 'attnres8'), (0, 'attnres_2x'), (0, 'memory_2x')],
}
BATCH = 32
CALIBRATION_EVERY = 512
DEVICE = 'cuda'  # tests switch this to 'cpu' with tiny fixtures


def inputs(seed):
    meta = manifest(seed)
    bind = meta['data_binding']
    rp = bind['prior_recipe_pin']
    if sha(rp['path']) != rp['sha256']:
        raise ValueError('Historical recipe mismatch')
    recipe = read(Path(rp['path']))['config']
    cal_file = recipe['calibration_indices']
    if sha(cal_file) != bind['input_pins'][cal_file]:
        raise ValueError('Calibration rows changed')
    row_path = OLD/'rows'/f's{seed}.npy'
    if sha(row_path) != ROW_PINS[seed]:
        raise ValueError('Training rows changed')
    ids = np.load(row_path, mmap_mode='r')
    measurement = np.array(meta['row_ids'], dtype=np.int64)
    cal = np.load(cal_file)
    return meta, Config(**meta['checkpoint_proofs']['model_config']), Rows(recipe['data']), ids, cal, measurement


def make_prepare(jobs):
    def prepare(base):
        record = {}
        for seed in sorted({s for s, _ in jobs}):
            meta, config, rows, ids, cal, measurement = inputs(seed)
            need = max(STEPS[a] for s, a in jobs if s == seed) * BATCH
            if len(ids) < need:
                raise ValueError(f'Need {need} training rows, have {len(ids)}')
            if np.intersect1d(np.asarray(ids[:need]), np.concatenate([cal, measurement])).size:
                raise ValueError('Training rows overlap evaluation rows')
            if len(measurement) != 512 or len(cal) != 256:
                raise ValueError('Unexpected evaluation row counts')
            record[str(seed)] = dict(row_sha256=ROW_PINS[seed], train_rows=need)
        write_json(base/'prepared.json', dict(seeds=record, measurement_rows=512, calibration_rows=256,
                                              config=config.__dict__, jobs=jobs))
    return prepare


def build(config, arm, device, seed):
    torch.manual_seed(seed)  # identical base initialization in every arm of a seed
    return LoopScreen(config, arm).to(device)


def check_parity(got, ref):
    """CPU-vs-device token-loss parity. Round-2 a01 showed FP32 rounding of up to 1.6e-4 relative on
    1-2 of 960 tokens for 17-25-sublayer AttnRes stacks; real kernel/mask bugs differ by orders more.
    Elementwise tolerance 1e-3 plus a tight 1e-4 bound on the mean absolute difference."""
    torch.testing.assert_close(got, ref, atol=1e-3, rtol=1e-3)
    mean_abs = float((got.double() - ref.double()).abs().mean())
    if mean_abs > 1e-4:
        raise AssertionError(f'Mean CPU/device token-loss difference {mean_abs:.3g} exceeds 1e-4')


def qualify(base, seed, arm, config, rows, cal):
    """Actual-GPU parity against CPU at init and with perturbed new parameters; one finite update."""
    out = base/f's{seed}'/f'qualification-{arm}'
    out.mkdir(parents=True, exist_ok=False)
    gpu, cpu = build(config, arm, DEVICE, seed), build(config, arm, 'cpu', seed)
    x = rows.batch(cal[:2], 'cpu')
    path = native_path(arm)
    for perturb in (False, True):
        if perturb:
            with torch.no_grad():
                g = torch.Generator().manual_seed(7)
                for name, p in cpu.named_parameters():
                    if name.startswith(('memory_', 'message_gate', 'attnres_')):
                        p.copy_(torch.randn(p.shape, generator=g) * .3)
            gpu.load_state_dict(cpu.state_dict())
        for passes in ((1, 3, 5) if arm in LOOP_ARMS else (3,)):
            cpu.passes = gpu.passes = passes
            with torch.inference_mode(), measurement_runtime('cpu'), anchor_runtime('cpu'):
                ref = cpu.token_losses(x, path)
            with torch.inference_mode(), measurement_runtime(DEVICE), anchor_runtime(DEVICE):
                got = gpu.token_losses(x.to(DEVICE), path).cpu()
            check_parity(got, ref)
    model = build(config, arm, DEVICE, seed).train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr_at(0, STEPS[arm]), betas=(.9, .95), eps=1e-8, weight_decay=0)
    with training_runtime(DEVICE), anchor_runtime(DEVICE):
        with torch.autocast(DEVICE, dtype=torch.bfloat16):
            loss = model.nll(rows.batch(cal[:BATCH], DEVICE), path).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        opt.step()
    if not torch.isfinite(loss):
        raise ValueError('Nonfinite qualification loss')
    write_json(out/'passed.json', dict(seed=seed, arm=arm, actual_gpu=True, parity=True, finite_update=True))


def fit(base, seed, arm, meta, config, rows, ids, cal, measurement):
    out = base/f's{seed}'/arm
    out.mkdir(parents=True, exist_ok=False)
    model = build(config, arm, DEVICE, seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr_at(0, STEPS[arm]), betas=(.9, .95), eps=1e-8, weight_decay=0)
    total = STEPS[arm]
    path = native_path(arm)
    binding = dict(rows_sha256=ROW_PINS[seed], seed=seed, arm=arm, steps=total)

    def evaluate(data, order=path, passes=3):
        model.passes = passes
        return score(model, rows, data, {'v': dict(path=order, skip=None)}, DEVICE)['v']

    def calibration(step):
        with (out/'calibration.jsonl').open('a') as f:
            print(json.dumps(dict(step=step, nll=float(evaluate(cal).mean()),
                                  block_applications=step*block_applications(arm))), file=f)

    calibration(0)
    started = time.time()
    with training_runtime(DEVICE), anchor_runtime(DEVICE):
        for step in range(total):
            for group in opt.param_groups:
                group['lr'] = lr_at(step, total)
            model.passes = train_passes(arm, step) or 3
            model.train()
            x = rows.batch(ids[step*BATCH:(step+1)*BATCH], DEVICE)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(DEVICE, dtype=torch.bfloat16):
                loss = model.nll(x, path).mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            opt.step()
            done = step + 1
            if done % 128 == 0:
                elapsed = time.time() - started
                write_json(out/'progress.json', dict(step=done, total=total, last_batch=float(loss.detach()),
                                                     elapsed=elapsed, tokens_per_s=done*BATCH*512/elapsed))
            if done % CALIBRATION_EVERY == 0:
                calibration(done)
    train_seconds = time.time() - started
    save_state(out/'terminal.pt', model, opt, seed, arm, total, binding)
    values = {'native': evaluate(measurement)}
    if SPECS[arm]['blocks'] == 4:
        values['swap'] = evaluate(measurement, SWAP4)
    if arm in LOOP_ARMS:
        for passes in range(1, 7):
            values[f'native_p{passes}'] = evaluate(measurement, passes=passes)
    if SPECS[arm]['loop'] == 'memory':
        model.memory_enabled = False
        values['memory_off'] = evaluate(measurement)
        model.memory_enabled = True
    extra = {}
    if SPECS[arm]['loop'] == 'gated':
        g = model.message_gate.detach().float()
        extra['message_gate'] = dict(mean=float(g.mean()), abs_mean=float(g.abs().mean()),
                                     min=float(g.min()), max=float(g.max()))
    if SPECS[arm]['mix'] == 'attnres':
        extra['attnres_query_norm'] = model.attnres_query.detach().float().norm(dim=-1).tolist()
    np.savez_compressed(out/'scores.npz', row_ids=measurement, **values)
    write_json(out/'summary.json', dict(
        binding=binding, step=total, rows=len(measurement), score_sha256=sha(out/'scores.npz'),
        nll={k: float(v.mean()) for k, v in values.items()}, train_seconds=train_seconds,
        tokens_per_s=total*BATCH*512/train_seconds, block_applications_per_token=block_applications(arm),
        parameters=sum(p.numel() for p in model.parameters()),
        non_embedding_parameters=sum(p.numel() for n, p in model.named_parameters() if not n.startswith('embed')),
        **extra))


def worker(base, seed, arm, action):
    meta, config, rows, ids, cal, measurement = inputs(seed)
    if action == 'qualify':
        qualify(base, seed, arm, config, rows, cal)
    else:
        fit(base, seed, arm, meta, config, rows, ids, cal, measurement)


def make_experiment(jobs):
    def experiment(base):
        module = 'scripts.loop_screen_study'
        stage(base, 'qualify', jobs, module)
        for seed, arm in jobs:
            if read(base/f's{seed}'/f'qualification-{arm}'/'passed.json')['arm'] != arm:
                raise ValueError('Missing qualification')
        stage(base, 'fit', jobs, module)
        report, backups = {}, {}
        for seed, arm in jobs:
            out = base/f's{seed}'/arm
            result = read(out/'summary.json')
            if result['step'] != STEPS[arm] or result['rows'] != 512 or sha(out/'scores.npz') != result['score_sha256']:
                raise ValueError('Invalid terminal: '+arm)
            report[f's{seed}/{arm}'] = result
            backup = base/'backup'/f's{seed}'/arm/'terminal.pt'
            backup.parent.mkdir(parents=True)
            shutil.copyfile(out/'terminal.pt', backup)
            expected = read(out/'terminal.json')['sha256']
            if sha(backup) != expected:
                raise ValueError('Terminal backup mismatch')
            backups[str(backup)] = expected
        write_json(base/'report.json', report)
        write_json(base/'backup.json', backups)
    return experiment


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=('queue', 'qualify', 'fit'))
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--seed', type=int, choices=(0, 1))
    p.add_argument('--arm', choices=ALL_ARMS)
    p.add_argument('--round', type=int, choices=tuple(ROUNDS), default=2)
    p.add_argument('--handoff', type=Path)
    p.add_argument('--handoff-sha256')
    a = p.parse_args()
    if a.action == 'queue':
        jobs = ROUNDS[a.round]
        try:
            supervise(a.base, make_prepare(jobs), make_experiment(jobs), a.handoff, a.handoff_sha256)
        except Exception as err:
            write_json(a.base/'failure.json', dict(reason=repr(err)))
            raise
    else:
        worker(a.base, a.seed, a.arm, a.action)
