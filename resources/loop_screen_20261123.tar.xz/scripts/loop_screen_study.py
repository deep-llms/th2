"""One-seed loop screen (8 arms, one GPU each) from scratch on verified DCLM rows.

Design and decision rules: docs/LOOP_SCREEN_20261123.md. Reuses the verified
long-study seed-0 row array, measurement and calibration rows, and the owned
native-burn handoff supervisor from the completed anchor studies.
"""
import argparse
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from efficient_llm.warm_order.adaptation_runtime import measurement_runtime, training_runtime
from efficient_llm.warm_order.data import Rows, sha
from efficient_llm.warm_order.embedding_anchor_runtime import anchor_runtime
from efficient_llm.warm_order.horizon_train import write_json
from efficient_llm.warm_order.loop_screen import (ARMS, LOOP_ARMS, NATIVE4, NATIVE8, STEPS, SWAP4,
                                                  LoopScreen, block_applications, lr_at, train_passes)
from efficient_llm.warm_order.model import Config
from scripts.anchor_long_study import manifest, read, save_state, score
from scripts.anchor_long_queue import stage, supervise

OUTPUTS = Path('/mnt/local/_outputs/deep-llms_th2')
OLD = OUTPUTS/'anchor_long_20261122_a01'
ROW_PIN = '70fc5792ed95b9ad3931a9604f29670d6769905407c06eb24a62cf8df0fe2853'  # verified long-study s0 rows
SEED = 0
BATCH = 32
CALIBRATION_EVERY = 512
DEVICE = 'cuda'  # tests switch this to 'cpu' with tiny fixtures


def inputs():
    meta = manifest(SEED)
    bind = meta['data_binding']
    rp = bind['prior_recipe_pin']
    if sha(rp['path']) != rp['sha256']:
        raise ValueError('Historical recipe mismatch')
    recipe = read(Path(rp['path']))['config']
    cal_file = recipe['calibration_indices']
    if sha(cal_file) != bind['input_pins'][cal_file]:
        raise ValueError('Calibration rows changed')
    row_path = OLD/'rows'/f's{SEED}.npy'
    if sha(row_path) != ROW_PIN:
        raise ValueError('Training rows changed')
    ids = np.load(row_path, mmap_mode='r')
    measurement = np.array(meta['row_ids'], dtype=np.int64)
    cal = np.load(cal_file)
    return meta, Config(**meta['checkpoint_proofs']['model_config']), Rows(recipe['data']), ids, cal, measurement


def prepare(base):
    meta, config, rows, ids, cal, measurement = inputs()
    need = max(STEPS.values()) * BATCH
    if len(ids) < need:
        raise ValueError(f'Need {need} training rows, have {len(ids)}')
    train = np.asarray(ids[:need])
    if np.intersect1d(train, np.concatenate([cal, measurement])).size:
        raise ValueError('Training rows overlap evaluation rows')
    if len(measurement) != 512 or len(cal) != 256:
        raise ValueError('Unexpected evaluation row counts')
    write_json(base/'prepared.json', dict(row_sha256=ROW_PIN, train_rows=need, measurement_rows=512,
                                          calibration_rows=256, config=config.__dict__))


def path_for(arm):
    return NATIVE8 if arm == 'dense8' else NATIVE4


def build(config, arm, device):
    torch.manual_seed(SEED)  # identical base initialization in every arm
    return LoopScreen(config, arm).to(device)


def qualify(base, arm, config, rows, cal):
    """Actual-GPU parity against CPU at init and with perturbed new parameters; one finite update."""
    out = base/f's{SEED}'/f'qualification-{arm}'
    out.mkdir(parents=True, exist_ok=False)
    gpu, cpu = build(config, arm, DEVICE), build(config, arm, 'cpu')
    x = rows.batch(cal[:2], 'cpu')
    for perturb in (False, True):
        if perturb:
            with torch.no_grad():
                g = torch.Generator().manual_seed(7)
                for name, p in cpu.named_parameters():
                    if name.startswith(('memory_', 'message_gate', 'attnres_')):
                        p.copy_(torch.randn(p.shape, generator=g) * .3)
            gpu.load_state_dict(cpu.state_dict())
        for passes in ((1, 3, 5) if arm in LOOP_ARMS else (3,)):
            cpu.passes = gpu.passes = passes
            with torch.inference_mode(), measurement_runtime('cpu'), anchor_runtime('cpu'):
                ref = cpu.token_losses(x, path_for(arm))
            with torch.inference_mode(), measurement_runtime(DEVICE), anchor_runtime(DEVICE):
                got = gpu.token_losses(x.to(DEVICE), path_for(arm)).cpu()
            torch.testing.assert_close(got, ref, atol=1e-4, rtol=1e-4)
    model = build(config, arm, DEVICE).train()
    opt = torch.optim.AdamW(model.parameters(), lr=lr_at(0, STEPS[arm]), betas=(.9, .95), eps=1e-8, weight_decay=0)
    with training_runtime(DEVICE), anchor_runtime(DEVICE):
        with torch.autocast(DEVICE, dtype=torch.bfloat16):
            loss = model.nll(rows.batch(cal[:BATCH], DEVICE), path_for(arm)).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        opt.step()
    if not torch.isfinite(loss):
        raise ValueError('Nonfinite qualification loss')
    write_json(out/'passed.json', dict(seed=SEED, arm=arm, actual_gpu=True, parity=True, finite_update=True))


def fit(base, arm, meta, config, rows, ids, cal, measurement):
    out = base/f's{SEED}'/arm
    out.mkdir(parents=True, exist_ok=False)
    model = build(config, arm, DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=lr_at(0, STEPS[arm]), betas=(.9, .95), eps=1e-8, weight_decay=0)
    total = STEPS[arm]
    path = path_for(arm)
    binding = dict(rows_sha256=ROW_PIN, seed=SEED, arm=arm, steps=total)

    def evaluate(data, order=path, passes=3):
        model.passes = passes
        return score(model, rows, data, {'v': dict(path=order, skip=None)}, DEVICE)['v']

    def calibration(step):
        with (out/'calibration.jsonl').open('a') as f:
            print(json.dumps(dict(step=step, nll=float(evaluate(cal).mean()),
                                  block_applications=step*block_applications(arm))), file=f)

    calibration(0)
    started = time.time()
    with training_runtime(DEVICE), anchor_runtime(DEVICE):
        for step in range(total):
            for group in opt.param_groups:
                group['lr'] = lr_at(step, total)
            model.passes = train_passes(arm, step) or 3
            model.train()
            x = rows.batch(ids[step*BATCH:(step+1)*BATCH], DEVICE)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(DEVICE, dtype=torch.bfloat16):
                loss = model.nll(x, path).mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            opt.step()
            done = step + 1
            if done % 128 == 0:
                elapsed = time.time() - started
                write_json(out/'progress.json', dict(step=done, total=total, last_batch=float(loss.detach()),
                                                     elapsed=elapsed, tokens_per_s=done*BATCH*512/elapsed))
            if done % CALIBRATION_EVERY == 0:
                calibration(done)
    train_seconds = time.time() - started
    save_state(out/'terminal.pt', model, opt, SEED, arm, total, binding)
    values = {'native': evaluate(measurement)}
    if arm != 'dense8':
        values['swap'] = evaluate(measurement, SWAP4)
    if arm in LOOP_ARMS:
        for passes in range(1, 7):
            values[f'native_p{passes}'] = evaluate(measurement, passes=passes)
    if arm == 'memory':
        model.memory_enabled = False
        values['memory_off'] = evaluate(measurement)
        model.memory_enabled = True
    extra = {}
    if arm in ('gated', 'gated_var'):
        g = model.message_gate.detach().float()
        extra['message_gate'] = dict(mean=float(g.mean()), abs_mean=float(g.abs().mean()),
                                     min=float(g.min()), max=float(g.max()))
    if arm == 'attnres':
        extra['attnres_query_norm'] = model.attnres_query.detach().float().norm(dim=-1).tolist()
    np.savez_compressed(out/'scores.npz', row_ids=measurement, **values)
    write_json(out/'summary.json', dict(
        binding=binding, step=total, rows=len(measurement), score_sha256=sha(out/'scores.npz'),
        nll={k: float(v.mean()) for k, v in values.items()}, train_seconds=train_seconds,
        tokens_per_s=total*BATCH*512/train_seconds, block_applications_per_token=block_applications(arm),
        parameters=sum(p.numel() for p in model.parameters()),
        non_embedding_parameters=sum(p.numel() for n, p in model.named_parameters() if not n.startswith('embed')),
        **extra))


def worker(base, arm, action):
    meta, config, rows, ids, cal, measurement = inputs()
    if action == 'qualify':
        qualify(base, arm, config, rows, cal)
    else:
        fit(base, arm, meta, config, rows, ids, cal, measurement)


def experiment(base):
    jobs = [(SEED, arm) for arm in ARMS]
    module = 'scripts.loop_screen_study'
    stage(base, 'qualify', jobs, module)
    for _, arm in jobs:
        if read(base/f's{SEED}'/f'qualification-{arm}'/'passed.json')['arm'] != arm:
            raise ValueError('Missing qualification')
    stage(base, 'fit', jobs, module)
    report, backups = {}, {}
    for _, arm in jobs:
        out = base/f's{SEED}'/arm
        result = read(out/'summary.json')
        if result['step'] != STEPS[arm] or result['rows'] != 512 or sha(out/'scores.npz') != result['score_sha256']:
            raise ValueError('Invalid terminal: '+arm)
        report[arm] = result
        backup = base/'backup'/arm/'terminal.pt'
        backup.parent.mkdir(parents=True)
        shutil.copyfile(out/'terminal.pt', backup)
        expected = read(out/'terminal.json')['sha256']
        if sha(backup) != expected:
            raise ValueError('Terminal backup mismatch')
        backups[str(backup)] = expected
    write_json(base/'report.json', report)
    write_json(base/'backup.json', backups)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=('queue', 'qualify', 'fit'))
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--seed', type=int, choices=(SEED,))
    p.add_argument('--arm', choices=ARMS)
    p.add_argument('--handoff', type=Path)
    p.add_argument('--handoff-sha256')
    a = p.parse_args()
    if a.action == 'queue':
        try:
            supervise(a.base, prepare, experiment, a.handoff, a.handoff_sha256)
        except Exception as err:
            write_json(a.base/'failure.json', dict(reason=repr(err)))
            raise
    else:
        worker(a.base, a.arm, a.action)
