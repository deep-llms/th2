"""One-seed loop screen: dense baselines, three loop mechanisms and AttnRes.

Design and pre-registered decision rules: docs/LOOP_SCREEN_20261123.md.
All arms reuse the EmbeddingAnchor embedding, native dense Block and shared
tokenwise head, so only the depth computation differs between arms.
Middle "path" names stored block identities; for loop arms path[0] is the
prelude, path[1:3] the looped core and path[3] the coda.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from efficient_llm.dot_pool.model import Block, Config as BlockConfig
from .embedding_anchor import EmbeddingAnchor

ARMS = ('dense4', 'dense4_2x', 'dense8', 'serial', 'memory', 'gated', 'gated_var', 'attnres')
LOOP_ARMS = ('serial', 'memory', 'gated', 'gated_var')
STEPS = {arm: 12288 for arm in ARMS} | {'dense4_2x': 24576}
VAR_PASSES = (3, 1, 3, 2, 3, 4, 3, 5)  # P(3)=1/2, P(1|2|4|5)=1/8 each, mean 3
NATIVE4 = (0, 1, 2, 3)
SWAP4 = (0, 2, 1, 3)
NATIVE8 = tuple(range(8))


def lr_at(step, total, peak=6e-4, warmup=128, cooldown=0.2):
    """Warmup-stable-decay: linear warm-up, constant, linear decay to 0 over the last 20%."""
    if type(step) is not int or not 0 <= step < total:
        raise ValueError('step outside schedule')
    start = int(total * (1 - cooldown))
    if step < warmup:
        return peak * (step + 1) / warmup
    if step < start:
        return peak
    return peak * (total - step) / (total - start)


def train_passes(arm, step):
    if arm == 'gated_var':
        return VAR_PASSES[step % len(VAR_PASSES)]
    return 3 if arm in LOOP_ARMS else None


def block_applications(arm, passes=3):
    if arm in LOOP_ARMS:
        return 2 + 2 * passes
    return 8 if arm == 'dense8' else 4


class LoopScreen(EmbeddingAnchor):
    def __init__(self, config, arm):
        super().__init__(config)  # identical base init (embed, B0..B3, head) for every arm
        if arm not in ARMS:
            raise ValueError('Unknown screen arm')
        self.arm = arm
        self.passes = 3
        self.memory_enabled = True
        d = config.d
        if arm == 'dense8':
            bc = BlockConfig(d=d, heads=config.heads, kv_heads=config.kv_heads,
                             head_dim=config.head_dim, ff=config.ff)
            extra = [Block(bc, True) for _ in range(4)]
            for block in extra:
                for module in block.modules():
                    if isinstance(module, nn.Linear):
                        nn.init.normal_(module.weight, std=.02)
            self.blocks.extend(extra)
        if arm == 'memory':
            self.memory_query = nn.Parameter(torch.zeros(2, d))
            self.memory_gain = nn.Parameter(torch.zeros(2, d))
        if arm in ('gated', 'gated_var'):
            self.message_gate = nn.Parameter(torch.zeros(d))  # closed at init: every pass = one pass
        if arm == 'attnres':
            self.attnres_query = nn.Parameter(torch.zeros(9, d))  # 4 blocks x 2 sublayers + readout

    # ---- shared helpers -------------------------------------------------
    def _guard(self, x):
        from .embedding_anchor_runtime import anchor_device
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if x.ndim != 2 or not 1 <= x.shape[1] <= self.c.length:
            raise ValueError('Invalid token matrix')

    def _check_path(self, path):
        path = tuple(path)
        expected = set(NATIVE8) if self.arm == 'dense8' else set(NATIVE4)
        if set(path) != expected or len(path) != len(expected):
            raise ValueError('Path must be a permutation of all stored blocks')
        if self.arm in LOOP_ARMS and (path[0], path[3]) != (0, 3):
            raise ValueError('Loop arms keep prelude 0 and coda 3 fixed')
        if self.arm in LOOP_ARMS and not 1 <= self.passes <= 16:
            raise ValueError('Pass count outside supported range')
        return path

    def read_memory(self, h, sources, identity):
        # Identical to anchor_loop.LoopAnchor.read_memory (completed long-loop study).
        values = torch.stack([F.rms_norm(v.float(), (self.c.d,), eps=1e-6) for v in sources], dim=-2)
        q = self.memory_query[identity - 1]
        weights = torch.softmax((values * q).sum(dim=-1) / math.sqrt(self.c.d), dim=-1)
        message = (values * weights.unsqueeze(-1)).sum(dim=-2)
        scale = (h.float().square().mean(dim=-1, keepdim=True) + 1e-6).sqrt()
        return h + scale * self.memory_gain[identity - 1].tanh() * message

    def _attnres_mix(self, sources, index):
        """Kimi AttnRes: softmax over depth of w^T RMSNorm(v_i), w zero-init -> uniform mean."""
        values = torch.stack(sources, dim=0)
        keys = F.rms_norm(values.float(), (self.c.d,), eps=1e-6)
        logits = (keys * self.attnres_query[index].float()).sum(-1)
        weights = torch.softmax(logits, dim=0).to(values.dtype)
        return (weights.unsqueeze(-1) * values).sum(0)

    # ---- forward ----------------------------------------------------------
    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('Screen arms take no anchor, donor or skip options')
        self._guard(x)
        path = self._check_path(path)
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        e = self.embed(x)
        if self.arm == 'attnres':
            return self._attnres_hidden(e, path, pos, seg)
        if self.arm not in LOOP_ARMS:
            h = e
            for identity in path:
                h = self.blocks[identity](h, pos, seg)
            return h
        prelude = self.blocks[path[0]](e, pos, seg)
        core = path[1:3]
        if self.arm in ('gated', 'gated_var'):
            message = None
            for _ in range(self.passes):
                h = prelude if message is None else prelude + self.message_gate * (message - prelude)
                for identity in core:
                    h = self.blocks[identity](h, pos, seg)
                message = h
            return self.blocks[path[3]](message, pos, seg)
        h = prelude
        previous = ()
        for _ in range(self.passes):
            current = []
            for identity in core:
                if self.arm == 'memory' and self.memory_enabled:
                    h = self.read_memory(h, (e, prelude, *previous), identity)
                h = self.blocks[identity](h, pos, seg)
                current.append(h)
            previous = tuple(current)
        return self.blocks[path[3]](h, pos, seg)

    def _attnres_hidden(self, e, path, pos, seg):
        sources = [e]
        for identity in path:
            block = self.blocks[identity]
            x = self._attnres_mix(sources, 2 * identity)
            sources.append(block.self_attn(block.input_layernorm(x), pos, seg))
            x = self._attnres_mix(sources, 2 * identity + 1)
            sources.append(block.mlp(block.post_attention_layernorm(x)))
        return self._attnres_mix(sources, 8)
