"""Looped baselines without DOT's T layer, at the same 4 stored blocks and the same block applications
(docs/DOT_T_VS_LOOPS_20261125.md).

  cycle : blocks applied cyclically, B0 B1 B2 B3 B0 B1 B2 ... (cross-layer CYCLE sharing / a looped dense stack)
  prc   : prelude B0, a recurrent pair (B1 B2) applied alternately, coda B3 (middle looping, Huginn-style layout
          without input injection)
  dense : B0 B1 B2 B3 once (the base transformer; used with cross-layer shared heads, shared_heads.py)

Depth is counted in DOT units so sweeps line up with the sandwich: depth d means 2 d + 1 block applications, the same
as a DOT sandwich with d middles (T M ... T). test_depth overrides the depth at evaluation or per training step.
"""
import torch

from .embedding_anchor import EmbeddingAnchor


class BlockSchedule(EmbeddingAnchor):
    def __init__(self, config, arm, spec):
        super().__init__(config)  # identical base init (embed, B0..B3, head) to every other arm of the seed
        self.arm, self.spec = arm, spec
        self.kind, self.native_depth = spec['schedule'], spec.get('depth')
        self.native_apps = spec.get('apps')  # cycle only: an exact number of block applications (e.g. 8 = dense4 twice)
        if self.native_apps is not None and (self.kind != 'cycle' or self.native_depth is not None):
            raise ValueError('apps is a cycle-only alternative to depth')
        if self.kind not in ('cycle', 'prc', 'dense'):
            raise ValueError('unknown schedule')
        self.test_depth = None
        self.aux = None

    def order(self, depth):
        if self.kind == 'dense':  # B0 B1 B2 B3 once (no looping; depth is ignored)
            return [0, 1, 2, 3]
        apps = self.native_apps if depth is None else 2 * depth + 1
        if self.kind == 'cycle':
            return [i % 4 for i in range(apps)]
        return [0] + [1 + i % 2 for i in range(apps - 2)] + [3]

    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        from .embedding_anchor_runtime import anchor_device
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('looped baselines take no anchor, donor or skip options')
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if tuple(path) != (0, 1, 2, 3):
            raise ValueError('looped baselines take the native library path only')
        if x.ndim != 2 or not 1 <= x.shape[1] <= self.c.length:
            raise ValueError('Invalid token matrix')
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        segments = torch.zeros_like(x)
        h = self.embed(x)
        for b in self.order(self.test_depth or self.native_depth):
            h = self._run_block(b, h, pos, segments)
        return h

    def _run_block(self, b, h, pos, segments):
        return self.blocks[b](h, pos, segments)
