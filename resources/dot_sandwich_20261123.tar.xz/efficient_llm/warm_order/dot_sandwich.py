"""DOT sandwich with a token-level router, trained from scratch without warm-up (docs/DOT_SANDWICH_20261123.md).

User design (docs/EMBEDDING_ANCHOR_AND_TIED_TRANSLATOR_20261120.md, sections 3 and 8): tied translator T at every
boundary, a library of middles M_1..M_K, and a router placed BEFORE T that reads the current state and picks the
next middle j; T receives the recipient identity c_j (fixed sin-cos code per module, plus OUT for the readout).
Here every token decides its own path at every step:

    e -> T(e, c_j1) -> M_j1 -> T(., c_j2) -> M_j2 -> ... -> M_jD -> T(., c_OUT) -> H

Stored blocks: 0 = T, 1..3 = middles (identical base init to dense4). Modes: route (router per step, top-1 argmax,
Switch gate p on the chosen middle, balance loss), fixed (M1, M2, M3, ... cyclic), random (content-independent).
Residual: plain stream, or multi (each sublayer reads a softmax mix of the token's earlier outputs).
Middle attention is computed for all tokens per middle (keys/values of all positions are needed) and the chosen
output is selected; middle MLPs are dispatched sparsely with a deterministic permutation.
"""
import math

import torch
from torch import nn
from torch.nn import functional as F

from .dot_token import permute
from .embedding_anchor import EmbeddingAnchor

T_ID, MIDDLES = 0, (1, 2, 3)
BALANCE = .01
RL_EPSILON, RL_ENTROPY = .05, .01  # rl: uniform exploration share and entropy bonus
CF_ROWS = 4  # cf: sequences per batch whose tokens are re-run with every middle at every step


def recipient_codes(n, d):
    """Fixed sin-cos identity vectors (like absolute position codes) for module ids 0..n-1, unit RMS."""
    pos = torch.arange(n, dtype=torch.float32)[:, None]
    freq = torch.exp(-math.log(10000.) * torch.arange(0, d, 2, dtype=torch.float32) / d)
    code = torch.zeros(n, d)
    code[:, 0::2], code[:, 1::2] = torch.sin(pos * freq), torch.cos(pos * freq)
    return code


class DotSandwich(EmbeddingAnchor):
    def __init__(self, config, arm, spec):
        super().__init__(config)  # embed, blocks 0..3, head: identical base init to dense4
        self.arm, self.spec, self.sw = arm, spec, spec['sandwich']
        d, depth, k = config.d, self.sw['depth'], len(MIDDLES)
        if self.sw['residual'] == 'multi':
            self.attnres_query = nn.Parameter(torch.zeros(2 * 4 + 1, d))  # (block, sublayer) + readout
            self.attnres_router = nn.Parameter(torch.zeros(depth, d))
        # small random init: no exact argmax ties (CPU/GPU tie-breaking could differ)
        self.dot_router = nn.Parameter(torch.randn(depth, k, d) * .02)
        self.register_buffer('codes', recipient_codes(k + 1, d), persistent=False)  # middles 1..3 -> 0..2, OUT -> 3
        self.recipient = nn.Linear(d, d, bias=False)
        nn.init.normal_(self.recipient.weight, std=.02)
        self.aux = None
        self.trace = None
        self.generator = None  # rl: explicit sampling generator during training
        self.forced = None  # cf: {step: (B, L) choice} overrides while collecting counterfactual losses
        self._logp, self._logits, self._choices = [], [], []

    # ----- helpers -------------------------------------------------------------------------------
    @staticmethod
    def _key(v):
        return F.rms_norm(v.float(), (v.shape[-1],), eps=1e-6)

    @staticmethod
    def _mix(values, keys, query):
        weights = torch.softmax((keys * query.float()).sum(-1), dim=0).to(values.dtype)
        return (weights.unsqueeze(-1) * values).sum(0)

    def _choose(self, state, step, shape):
        k, mode = len(MIDDLES), self.sw['mode']
        if self.forced is not None and step in self.forced:
            choice = self.forced[step]
            if mode in ('route', 'cf'):
                probs = torch.softmax(F.rms_norm(state.float(), (self.c.d,), eps=1e-6) @ self.dot_router[step].float().t(), -1)
                return choice, probs.gather(-1, choice.unsqueeze(-1))
            return choice, None
        if mode == 'rl':
            logits = F.rms_norm(state.float(), (self.c.d,), eps=1e-6) @ self.dot_router[step].float().t()
            logp = torch.log_softmax(logits, -1)
            if self.training and torch.is_grad_enabled():
                if self.generator is None:
                    raise RuntimeError('rl routing needs an explicit generator')
                explore = (1 - RL_EPSILON) * logp.exp() + RL_EPSILON / k  # exploit the policy, explore new paths
                u = torch.rand(shape, generator=self.generator, device=state.device)
                choice = (explore.detach().cumsum(-1) < u.unsqueeze(-1)).sum(-1).clamp(max=k - 1)
                self._logp.append(logp.gather(-1, choice.unsqueeze(-1)).squeeze(-1))
                entropy = -(logp.exp() * logp).sum(-1).mean()
                self.aux = -RL_ENTROPY * entropy if self.aux is None else self.aux - RL_ENTROPY * entropy
            else:
                choice = logp.argmax(-1)
            return choice, None
        if mode == 'fixed':
            return torch.full(shape, step % k, dtype=torch.long, device=state.device), None
        if mode == 'random':
            g = torch.Generator(device='cpu').manual_seed(7919 * (step + 1))
            return torch.randint(0, k, shape, generator=g).to(state.device), None
        logits = F.rms_norm(state.float(), (self.c.d,), eps=1e-6) @ self.dot_router[step].float().t()
        probs = torch.softmax(logits, -1)
        choice = probs.argmax(-1)
        if mode == 'cf' and self.training and torch.is_grad_enabled():
            self._logits.append(logits)
            self._choices.append(choice.detach())
        if self.training and torch.is_grad_enabled():
            frac = F.one_hot(choice, k).float().reshape(-1, k).mean(0)
            balance = BALANCE * k * (frac.detach() * probs.reshape(-1, k).mean(0)).sum()
            self.aux = balance if self.aux is None else self.aux + balance
        return choice, probs.gather(-1, choice.unsqueeze(-1))

    def _condition(self, code_index, dtype):
        """Projected recipient identity per token; code_index (B, L) in 0..3 (3 = OUT)."""
        if not self.sw['recipient']:
            return None
        return self.recipient(self.codes[code_index].to(dtype))

    def _middle_mlp(self, u, choice):
        shape = u.shape
        flat, idx = u.reshape(-1, shape[-1]), choice.reshape(-1)
        perm = torch.argsort(idx, stable=True)
        inverse = torch.argsort(perm, stable=True)
        counts = torch.bincount(idx, minlength=len(MIDDLES)).tolist()
        parts = torch.split(permute(flat, perm, inverse), counts)
        outs = [self.blocks[MIDDLES[j]].mlp(self.blocks[MIDDLES[j]].post_attention_layernorm(p)) if len(p) else p
                for j, p in enumerate(parts)]
        return permute(torch.cat(outs), inverse, perm).reshape(shape)

    # ----- forward -------------------------------------------------------------------------------
    def hidden(self, x, path, *, alpha=1., donor=None, skip=None):
        from .embedding_anchor_runtime import anchor_device
        if alpha != 1. or donor is not None or skip is not None:
            raise ValueError('DOT sandwich takes no anchor, donor or skip options')
        if x.device.type != anchor_device() or self.embed.weight.device.type != anchor_device():
            raise RuntimeError('Explicit matching anchor device scope required')
        if tuple(path) != (0, 1, 2, 3):
            raise ValueError('DOT sandwich takes the native library path only')
        if self.forced is None:
            self._logp, self._logits, self._choices = [], [], []
        return (self._multi if self.sw['residual'] == 'multi' else self._plain)(x)

    def extra_loss(self, x, token_losses):
        """Router learning signals that need the per-token LM losses of the forward just run.

        rl: REINFORCE on every step's sampled choice with the token's own loss as cost (batch-normalized advantage).
        cf: re-run the first CF_ROWS sequences with every middle forced at one step (other steps keep the
            current choices), label each token with the middle giving the lowest loss, cross-entropy on the router.
        """
        mode, p0 = self.sw['mode'], self.c.prefix - 1
        if mode == 'rl' and self._logp:
            adv = (token_losses - token_losses.mean()) / (token_losses.std() + 1e-6)
            logp = torch.stack(self._logp).sum(0)[:, p0:-1]  # positions that predict a scored token
            return (logp * adv.detach()).mean()
        if mode == 'cf' and self._logits:
            rows = min(CF_ROWS, x.shape[0])
            logits = [g[:rows] for g in self._logits]
            current = [c[:rows] for c in self._choices]
            labels = []
            with torch.no_grad():  # counterfactual forwards only; the router loss below keeps its graph
                for step in range(self.sw['depth']):
                    alts = []
                    for j in range(len(MIDDLES)):
                        self.forced = {s: (torch.full_like(current[s], j) if s == step else current[s])
                                       for s in range(self.sw['depth'])}
                        try:
                            alts.append(super().token_losses(x[:rows], (0, 1, 2, 3)))
                        finally:
                            self.forced = None
                    labels.append(torch.stack(alts, -1).argmin(-1))  # (rows, L - prefix)
            total = sum(F.cross_entropy(logits[step][:, p0:-1].reshape(-1, len(MIDDLES)), labels[step].reshape(-1))
                        for step in range(self.sw['depth']))
            return total / self.sw['depth']
        return None

    def _plain(self, x):
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        self.aux = None
        T = self.blocks[T_ID]
        h = self.embed(x)
        for step in range(self.sw['depth']):
            choice, gate = self._choose(h, step, x.shape)  # router BEFORE T reads the current state
            if self.trace is not None:
                self.trace.append(choice.detach())
            c = self._condition(choice, h.dtype)
            h = self._t(T, h, c, pos, seg)
            onehot = F.one_hot(choice, len(MIDDLES)).to(h.dtype)
            a = 0
            for j, b in enumerate(MIDDLES):
                a = a + onehot[..., j:j + 1] * self.blocks[b].self_attn(self.blocks[b].input_layernorm(h), pos, seg)
            h = h + (a * gate.to(a.dtype) if gate is not None else a)
            m = self._middle_mlp(h, choice)
            h = h + (m * gate.to(m.dtype) if gate is not None else m)
        out = torch.full(x.shape, len(MIDDLES), dtype=torch.long, device=x.device)
        return self._t(T, h, self._condition(out, h.dtype), pos, seg)

    @staticmethod
    def _t(T, h, c, pos, seg):
        """Tied translator conditioned on the recipient: c enters both sublayer inputs, not the stream."""
        u = h if c is None else h + c
        h = h + T.self_attn(T.input_layernorm(u), pos, seg)
        u = h if c is None else h + c
        return h + T.mlp(T.post_attention_layernorm(u))

    def _multi(self, x):
        pos = torch.arange(x.shape[1], device=x.device).expand_as(x)
        seg = torch.zeros_like(x)
        self.aux = None
        T, q = self.blocks[T_ID], self.attnres_query
        e = self.embed(x)
        sources, keys = [e], [self._key(e)]

        def mix(query):
            return self._mix(torch.stack(sources), torch.stack(keys), query)

        def add(v):
            sources.append(v)
            keys.append(self._key(v))

        def translator(c):
            u = mix(q[0])
            a = T.self_attn(T.input_layernorm(u if c is None else u + c), pos, seg)
            add(a)
            u = mix(q[1])
            add(T.mlp(T.post_attention_layernorm(u if c is None else u + c)))

        for step in range(self.sw['depth']):
            choice, gate = self._choose(mix(self.attnres_router[step]), step, x.shape)
            if self.trace is not None:
                self.trace.append(choice.detach())
            translator(self._condition(choice, e.dtype))
            onehot = F.one_hot(choice, len(MIDDLES)).to(e.dtype)
            a = 0
            for j, b in enumerate(MIDDLES):
                a = a + onehot[..., j:j + 1] * self.blocks[b].self_attn(self.blocks[b].input_layernorm(mix(q[2 * b])), pos, seg)
            add(a * gate.to(a.dtype) if gate is not None else a)
            query = (onehot.unsqueeze(-1) * q[3:8:2].to(e.dtype)).sum(-2)  # chosen middle's MLP query per token
            m = self._middle_mlp(mix(query), choice)
            add(m * gate.to(m.dtype) if gate is not None else m)
        out = torch.full(x.shape, len(MIDDLES), dtype=torch.long, device=x.device)
        translator(self._condition(out, e.dtype))
        return mix(q[8])
